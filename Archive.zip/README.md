# quicktextencrypt
Securely encrypt and decrypt text using AES-256 encryption. Protect sensitive information with a custom PIN. Ideal for safeguarding messages, notes, and personal data while browsing. Testing Cursor AI

## License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.
